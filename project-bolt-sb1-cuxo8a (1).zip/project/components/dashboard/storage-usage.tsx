"use client"

export function StorageUsage() {
  return (
    <div className="h-[300px] flex items-center justify-center bg-gray-100 dark:bg-gray-800 rounded-lg">
      [Storage Usage Chart]
    </div>
  )
}